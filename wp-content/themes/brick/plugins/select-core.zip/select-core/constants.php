<?php

define( 'BRICK_CORE_VERSION', '1.2.1' );
define( 'BRICK_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'BRICK_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'BRICK_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'BRICK_CORE_CPT_PATH', BRICK_CORE_ABS_PATH . '/modules/post-types' );
define( 'BRICK_CORE_MODULES_PATH', BRICK_CORE_ABS_PATH . '/modules' );
define( 'BRICK_CORE_MODULES_URL_PATH', BRICK_CORE_URL_PATH . 'modules' );